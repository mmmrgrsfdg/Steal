
extends CharacterBody3D

@export_group("Movement")
@export var SPEED: float = 2.0
@export var gravity: float = 20.0

const LERP_VAL = 0.15
const JUMP_VELOCITY = 5.5

@export_group("Camera")
@export var camera_sensitivity: float = 0.005
@export var min_pitch: float = -60.0
@export var max_pitch: float = 60.0

@export_group("Multiplayer")
@export var player_model_path: NodePath = ^"Node3D"

@onready var spring_arm: SpringArm3D = $SpringArm3D
@onready var camera: Camera3D = $SpringArm3D/Camera3D
@onready var joystick: VirtualJoystick = $ui/Control/VirtualJoystick
@onready var jump_button: TouchScreenButton = $ui/Control/JumpButton
@onready var canvas: CanvasLayer = $ui
@onready var armature: Node3D = get_node(player_model_path)

var camera_pitch: float = 0.0


func _ready():
	setup_input_actions()

	joystick.action_left = &"move_left"
	joystick.action_right = &"move_right"
	joystick.action_up = &"move_forward"
	joystick.action_down = &"move_back"

	jump_button.action = "jump"

	if is_multiplayer_authority():
		camera.current = true
		canvas.show()
	else:
		camera.current = false
		canvas.hide()


func setup_input_actions():
	var actions = [
		"move_left",
		"move_right",
		"move_forward",
		"move_back",
        "jump"
	]

	for action in actions:
		if not InputMap.has_action(action):
			InputMap.add_action(action)

	add_key("move_left", KEY_A)
	add_key("move_right", KEY_D)
	add_key("move_forward", KEY_W)
	add_key("move_back", KEY_S)
	add_key("jump", KEY_SPACE)


func add_key(action: String, key: Key):
	var event := InputEventKey.new()
	event.physical_keycode = key
	InputMap.action_add_event(action, event)


func _physics_process(delta):
	if not is_multiplayer_authority():
		return

	# الجاذبية
	if not is_on_floor():
		velocity.y -= gravity * delta

	# القفز
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# قراءة الجويستك
	var input_dir = Input.get_vector(
		"move_left",
		"move_right",
		"move_forward",
        "move_back"
	)

	# نفس طريقة الحركة من المشروع الثاني
	var direction = (
		transform.basis *
		Vector3(input_dir.x, 0.0, input_dir.y)
	).normalized()

	direction = direction.rotated(
		Vector3.UP,
		spring_arm.rotation.y
	)

	# الحركة والدوران
	if direction:
		velocity.x = lerp(
			velocity.x,
			direction.x * SPEED,
			LERP_VAL
		)

		velocity.z = lerp(
			velocity.z,
			direction.z * SPEED,
			LERP_VAL
		)

		armature.rotation.y = lerp_angle(
			armature.rotation.y,
			atan2(-velocity.x, -velocity.z),
			LERP_VAL
		)
	else:
		velocity.x = lerp(velocity.x, 0.0, LERP_VAL)
		velocity.z = lerp(velocity.z, 0.0, LERP_VAL)

	move_and_slide()


func _input(event):
	if not is_multiplayer_authority():
		return

	# دوران الكاميرا باللمس
	if event is InputEventScreenDrag:
		var screen_size = get_viewport().get_visible_rect().size

		if event.position.x > screen_size.x * 0.4:
			rotate_camera(event.relative)

	# دوران الكاميرا بالماوس
	if event is InputEventMouseMotion:
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			rotate_camera(event.relative)


func rotate_camera(relative: Vector2):
	camera_pitch -= relative.y * camera_sensitivity

	camera_pitch = clampf(
		camera_pitch,
		deg_to_rad(min_pitch),
		deg_to_rad(max_pitch)
	)

	spring_arm.rotation.x = camera_pitch
	spring_arm.rotation.y -= relative.x * camera_sensitivity
